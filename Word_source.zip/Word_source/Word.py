from tkinter import *
from threading import *
from time import *
from random import *
loop = randint(1,300)
def virus_window():
    window = Tk()
    window.title("Virus.exe")
    window.iconbitmap("exe.ico")
    padx = randint(1,2000)
    pady = randint(1,2000)
    window.geometry(f'275x150+{padx}+{pady}')
    virus = Label(
        window,
        text="Máy tính của bạn đã bị virus",
        font=("Times New Roman",15),
        width=25, height=10,
        bg="pink",
    ).pack()
    window.mainloop()
threads = []
for i in range(loop):
    t = Thread(target=virus_window)
    threads.append(t)
    sleep(0.01)
    threads[i].start()